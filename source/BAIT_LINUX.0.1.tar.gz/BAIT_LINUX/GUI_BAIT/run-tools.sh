cd /data/data/com.termux/files/usr/bin
cd hydra-gtk
cd -
./xhydra

wireshark-gtk
