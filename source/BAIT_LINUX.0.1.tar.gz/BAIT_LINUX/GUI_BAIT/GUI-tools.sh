clear

#hydra-gtk
cd /data/data/com.termux/files/usr/bin
git clone https://github.com/vanhauser-thc/thc-hydra/tree/master/hydra-gtk.git
cd hydra-gtk && sh ./make_xhydra.sh

#wireshark-gtk
apt install wireshark-gtk