#!/bin/bash
cd ../
cp -r BAIT_LINUX /data/data/com.termux/files/home/
rm -rv BAIT_LINUX
cd
cd BAIT_LINUX
cd pluig
mv -f samples.sh ../
mv -f keris.sh ../
mv -f gui.sh ../
cd ../
sh samples.sh
