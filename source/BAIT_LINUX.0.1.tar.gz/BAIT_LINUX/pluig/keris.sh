read -p "[+] Are you going to install root software? [Y/n]" dh
case $dh in
y)pkg install tsu
cd bin
chmod +x console-root.sh
cp -r console-root.sh /data/data/com.termux/files/usr/bin/file/
sh console-root.sh
cd
cd BAIT_LINUX
cd ../pluig
chmod +x update
mv update /data/data/com.termux/files/usr/bin
cd ../  ;;
esac